#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_MPU6050.h>

Adafruit_BMP280 bmp;
Adafruit_MPU6050 mpu;

const float SEA_LEVEL_HPA = 1013.25;  // потом поправим под местное давление
float groundAltitude = 0;             // высота "земли" для относительных измерений

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  // У BMP280 адрес бывает 0x76 или 0x77 — зависит от модуля
  if (!bmp.begin(0x76) && !bmp.begin(0x77)) {
    Serial.println("BMP280 не найден, проверь подключение");
    while (true) delay(1000);
  }
  if (!mpu.begin()) {
    Serial.println("MPU6050 не найден, проверь подключение");
    while (true) delay(1000);
  }

  bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
                  Adafruit_BMP280::SAMPLING_X2,
                  Adafruit_BMP280::SAMPLING_X16,
                  Adafruit_BMP280::FILTER_X4,
                  Adafruit_BMP280::STANDBY_MS_1);

  mpu.setAccelerometerRange(MPU6050_RANGE_16_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_44_HZ);

  // Калибровка нуля высоты: среднее по 50 измерениям
  float sum = 0;
  for (int i = 0; i < 50; i++) {
    sum += bmp.readAltitude(SEA_LEVEL_HPA);
    delay(20);
  }
  groundAltitude = sum / 50;

  Serial.println("t_ms,alt_m,press_pa,ax,ay,az,gx,gy,gz");
}

void loop() {
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  float alt = bmp.readAltitude(SEA_LEVEL_HPA) - groundAltitude;
  float press = bmp.readPressure();

  Serial.print(millis());       Serial.print(',');
  Serial.print(alt, 2);         Serial.print(',');
  Serial.print(press, 0);       Serial.print(',');
  Serial.print(a.acceleration.x, 2); Serial.print(',');
  Serial.print(a.acceleration.y, 2); Serial.print(',');
  Serial.print(a.acceleration.z, 2); Serial.print(',');
  Serial.print(g.gyro.x, 3);    Serial.print(',');
  Serial.print(g.gyro.y, 3);    Serial.print(',');
  Serial.println(g.gyro.z, 3);

  delay(20);  // ~50 Гц
}
