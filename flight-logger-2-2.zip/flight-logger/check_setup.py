"""Проверка: всё ли установлено для запуска симулятора."""
import sys

print("Python", sys.version.split()[0])
for name in ("numpy", "matplotlib"):
    try:
        m = __import__(name)
        print(f"[OK]  {name} {m.__version__}")
    except ImportError:
        print(f"[НЕТ] {name}  ->  py -m pip install {name}")
try:
    import tkinter
    print("[OK]  tkinter (окно с ползунками будет работать)")
except ImportError:
    print("[НЕТ] tkinter -> окно недоступно, используй run_simulation.bat")
