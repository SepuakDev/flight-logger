@echo off
cd /d "%~dp0simulation"
where py >nul 2>nul
if %errorlevel%==0 (py flight_sim_gui.py) else (python flight_sim_gui.py)
pause
