@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py check_setup.py) else (python check_setup.py)
pause
