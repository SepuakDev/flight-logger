@echo off
cd /d "%~dp0simulation"
where py >nul 2>nul
if %errorlevel%==0 (py flight_sim.py --log ..\data\example_flight_synthetic.csv --out flight_sim.png) else (python flight_sim.py --log ..\data\example_flight_synthetic.csv --out flight_sim.png)
echo.
echo Graph saved: simulation\flight_sim.png
pause
