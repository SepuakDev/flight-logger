"""
flight_sim.py — симулятор вертикального полёта модели ракеты с парашютом.

Модель (1D, вертикаль):
  - тяга по кривой (время, сила), масса падает линейно за время работы двигателя
  - сопротивление воздуха: F = 0.5 * rho * Cd * A * v * |v|
  - парашют раскрывается в апогее (с задержкой, если задана)
  - плотность воздуха постоянна (упрощение)

Запуск:
    python flight_sim.py                      # расчёт и график
    python flight_sim.py --log ../data/flight_01.csv   # + наложение реального лога
Лог должен быть в формате регистратора: t_ms,alt_m,...
"""
import argparse
from dataclasses import dataclass, field

import numpy as np
import matplotlib.pyplot as plt

G = 9.81      # м/с^2
RHO = 1.225   # кг/м^3, плотность воздуха у земли


@dataclass
class Rocket:
    mass_dry: float = 0.15          # кг, масса без топлива
    mass_prop: float = 0.01         # кг, масса топлива
    diameter: float = 0.045         # м, диаметр корпуса
    cd_body: float = 0.6            # коэфф. сопротивления корпуса
    chute_diameter: float = 0.45    # м, диаметр купола
    cd_chute: float = 1.0           # коэфф. сопротивления парашюта
    deploy_delay: float = 0.0       # с после апогея
    # кривая тяги: (время с, сила Н). Пустая кривая = полёт без двигателя
    thrust_curve: list = field(default_factory=lambda: [
        (0.0, 0.0), (0.05, 14.0), (0.2, 8.0), (0.8, 6.0), (0.9, 0.0),
    ])

    @property
    def burn_time(self):
        return self.thrust_curve[-1][0] if self.thrust_curve else 0.0

    def thrust(self, t):
        if not self.thrust_curve or t > self.burn_time:
            return 0.0
        ts, fs = zip(*self.thrust_curve)
        return float(np.interp(t, ts, fs))

    def mass(self, t):
        if self.burn_time == 0 or t >= self.burn_time:
            return self.mass_dry
        return self.mass_dry + self.mass_prop * (1 - t / self.burn_time)


def simulate(rocket, h0=0.0, dt=0.001, t_max=120.0):
    """Возвращает массивы t, h, v, a. h0 > 0 — сброс с высоты (тест парашюта)."""
    a_body = np.pi * (rocket.diameter / 2) ** 2
    a_chute = np.pi * (rocket.chute_diameter / 2) ** 2

    t, h, v = 0.0, h0, 0.0
    t_apogee = None
    ts, hs, vs, accs = [], [], [], []

    while t < t_max:
        # фаза: парашют раскрыт после апогея + задержка
        if t_apogee is None and v < 0 and t > rocket.burn_time:
            t_apogee = t
        chute_open = t_apogee is not None and t >= t_apogee + rocket.deploy_delay

        cd_a = rocket.cd_chute * a_chute if chute_open else rocket.cd_body * a_body
        m = rocket.mass(t)
        drag = -0.5 * RHO * cd_a * v * abs(v)
        force = rocket.thrust(t) - m * G + drag

        # стоим на земле, пока тяга не превысила вес
        if h <= 0 and v <= 0 and force <= 0:
            force, v, h = 0.0, 0.0, 0.0

        a = force / m
        v += a * dt          # полунеявный Эйлер
        h += v * dt
        t += dt

        ts.append(t); hs.append(h); vs.append(v); accs.append(a)

        if h <= 0 and v < 0 and t > rocket.burn_time:
            break  # приземление

    return np.array(ts), np.array(hs), np.array(vs), np.array(accs)


def summary(rocket, t, h, v, a):
    i_apo = int(np.argmax(h))
    # установившаяся скорость спуска: средняя за последние 2 секунды
    tail = v[t > t[-1] - 2.0]
    return {
        "Апогей, м": h[i_apo],
        "Время до апогея, с": t[i_apo],
        "Макс. скорость, м/с": v.max(),
        "Макс. ускорение, м/с^2": a.max(),
        "Скорость спуска, м/с": -tail.mean(),
        "Время полёта, с": t[-1],
    }


def load_log(path):
    """Читает CSV регистратора, возвращает (время с от старта подъёма, высота)."""
    data = np.genfromtxt(path, delimiter=",", names=True)
    t = data["t_ms"] / 1000.0
    h = data["alt_m"]
    # выравниваем время: старт там, где высота впервые выросла на 0.5 м
    idx = np.argmax(h > h[:20].mean() + 0.5)
    return t - t[idx], h


def plot(t, h, v, info, log=None, out="flight_sim.png"):
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
    ax1.plot(t, h, label="расчёт")
    if log is not None:
        ax1.plot(log[0], log[1], "--", label="реальный полёт")
    ax1.set_ylabel("Высота, м")
    ax1.set_title(f"Апогей {info['Апогей, м']:.1f} м, спуск {info['Скорость спуска, м/с']:.1f} м/с")
    ax1.grid(alpha=0.3)
    ax1.legend()
    ax2.plot(t, v, color="tab:orange")
    ax2.set_ylabel("Скорость, м/с")
    ax2.set_xlabel("Время, с")
    ax2.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"График сохранён: {out}")


if __name__ == "__main__":
    import matplotlib

    matplotlib.use("Agg")  # консольный режим: без окна, сразу в PNG
    p = argparse.ArgumentParser(description="Симулятор полёта модели ракеты")
    p.add_argument("--log", help="CSV-лог регистратора для наложения")
    p.add_argument("--out", default="flight_sim.png")
    args = p.parse_args()

    rocket = Rocket()
    t, h, v, a = simulate(rocket)
    info = summary(rocket, t, h, v, a)
    for k, val in info.items():
        print(f"{k}: {val:.2f}")
    plot(t, h, v, info, load_log(args.log) if args.log else None, args.out)
