"""
flight_sim_gui.py — графический интерфейс к симулятору полёта (tkinter + matplotlib).

Запуск:
    python flight_sim_gui.py

Слайдеры слева меняют параметры ракеты, график справа пересчитывается сразу.
Кнопка «Загрузить лог» накладывает реальный полёт из CSV регистратора.
Нужен файл flight_sim.py рядом.
"""
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except ImportError:
    raise SystemExit(
        "Не найден tkinter, окно открыть нельзя.\n"
        "Используй консольный режим: run_simulation.bat (он строит график в PNG)."
    )

import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import flight_sim as fs

BASE_CURVE = fs.Rocket().thrust_curve

# ключ, подпись, минимум, максимум, по умолчанию, шаг
PARAMS = [
    ("mass_dry", "Масса без топлива, г", 20, 500, 150, 5),
    ("mass_prop", "Масса топлива, г", 0, 50, 10, 1),
    ("diameter", "Диаметр корпуса, мм", 20, 100, 45, 1),
    ("cd_body", "Cd корпуса", 0.2, 1.2, 0.6, 0.05),
    ("chute_d", "Диаметр парашюта, см", 10, 120, 45, 1),
    ("cd_chute", "Cd парашюта", 0.5, 1.8, 1.0, 0.05),
    ("delay", "Задержка раскрытия, с", 0, 5, 0.0, 0.1),
    ("thrust_k", "Тяга, ×", 0.2, 3.0, 1.0, 0.05),
    ("h0", "Начальная высота, м", 0, 200, 0, 5),
]


def run_simulation(p, no_motor=False):
    """p — словарь параметров (единицы как в слайдерах). Возвращает (rocket, t, h, v, a)."""
    curve = [] if no_motor else [(t, f * p["thrust_k"]) for t, f in BASE_CURVE]
    rocket = fs.Rocket(
        mass_dry=p["mass_dry"] / 1000,
        mass_prop=p["mass_prop"] / 1000,
        diameter=p["diameter"] / 1000,
        cd_body=p["cd_body"],
        chute_diameter=p["chute_d"] / 100,
        cd_chute=p["cd_chute"],
        deploy_delay=p["delay"],
        thrust_curve=curve,
    )
    t, h, v, a = fs.simulate(rocket, h0=p["h0"], dt=0.002, t_max=60.0)
    return rocket, t, h, v, a


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("flight-logger — симулятор полёта")
        self.geometry("1150x700")
        self.minsize(900, 560)
        self.log = None
        self.scales = {}
        self.no_motor = tk.BooleanVar(value=False)
        self.result_text = tk.StringVar()
        self._job = None
        self._build_ui()
        self.recalc()

    # ---------- интерфейс ----------
    def _build_ui(self):
        left = ttk.Frame(self, padding=10)
        left.pack(side=tk.LEFT, fill=tk.Y)

        ttk.Label(left, text="Параметры ракеты", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        for key, label, lo, hi, default, step in PARAMS:
            ttk.Label(left, text=label).pack(anchor="w", pady=(6, 0))
            s = tk.Scale(left, from_=lo, to=hi, resolution=step, orient=tk.HORIZONTAL,
                         length=260, command=self._on_change)
            s.set(default)
            s.pack(anchor="w")
            self.scales[key] = s

        ttk.Checkbutton(left, text="Без двигателя (сброс с высоты)",
                        variable=self.no_motor, command=self.recalc).pack(anchor="w", pady=(10, 0))

        buttons = ttk.Frame(left)
        buttons.pack(anchor="w", pady=10)
        ttk.Button(buttons, text="Загрузить лог", command=self.load_log).grid(row=0, column=0, padx=(0, 4))
        ttk.Button(buttons, text="Убрать лог", command=self.clear_log).grid(row=0, column=1, padx=4)
        ttk.Button(buttons, text="Сохранить PNG", command=self.save_png).grid(row=0, column=2, padx=4)

        ttk.Label(left, textvariable=self.result_text, font=("Consolas", 10),
                  justify=tk.LEFT).pack(anchor="w", pady=(6, 0))

        right = ttk.Frame(self)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        self.fig = Figure(figsize=(7, 6), dpi=100)
        self.ax_h = self.fig.add_subplot(211)
        self.ax_v = self.fig.add_subplot(212, sharex=self.ax_h)
        self.canvas = FigureCanvasTkAgg(self.fig, master=right)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _on_change(self, _value=None):
        # небольшая задержка, чтобы не пересчитывать на каждый пиксель слайдера
        if self._job is not None:
            self.after_cancel(self._job)
        self._job = self.after(120, self.recalc)

    # ---------- расчёт и график ----------
    def params(self):
        return {k: s.get() for k, s in self.scales.items()}

    def recalc(self):
        self._job = None
        p = self.params()
        no_motor = self.no_motor.get()

        self.ax_h.clear()
        self.ax_v.clear()

        if no_motor and p["h0"] <= 0:
            self.result_text.set("Для сброса задай начальную\nвысоту больше 0.")
            self._draw_empty()
            return

        rocket, t, h, v, a = run_simulation(p, no_motor)

        if p["h0"] <= 0 and h.max() < 1.0:
            self.result_text.set("Ракета почти не взлетает:\nтяга близка к весу или меньше.")
            self._draw_empty()
            return

        info = fs.summary(rocket, t, h, v, a)
        self.result_text.set(
            f"Апогей:            {info['Апогей, м']:7.1f} м\n"
            f"Время до апогея:   {info['Время до апогея, с']:7.2f} с\n"
            f"Макс. скорость:    {max(0.0, info['Макс. скорость, м/с']):7.1f} м/с\n"
            f"Макс. ускорение:   {max(0.0, info['Макс. ускорение, м/с^2'] / fs.G):7.1f} g\n"
            f"Скорость спуска:   {info['Скорость спуска, м/с']:7.1f} м/с\n"
            f"Время полёта:      {info['Время полёта, с']:7.1f} с"
        )

        self.ax_h.plot(t, h, label="расчёт")
        i = int(np.argmax(h))
        self.ax_h.plot(t[i], h[i], "o", color="tab:red")
        self.ax_h.annotate(f"{h[i]:.1f} м", (t[i], h[i]), textcoords="offset points", xytext=(8, -4))
        if self.log is not None:
            self.ax_h.plot(self.log[0], self.log[1], "--", label="реальный полёт")
            self.ax_h.legend()
        self.ax_v.plot(t, v, color="tab:orange")
        self._decorate()
        self.canvas.draw_idle()

    def _draw_empty(self):
        self._decorate()
        self.canvas.draw_idle()

    def _decorate(self):
        self.ax_h.set_ylabel("Высота, м")
        self.ax_v.set_ylabel("Скорость, м/с")
        self.ax_v.set_xlabel("Время, с")
        self.ax_h.grid(alpha=0.3)
        self.ax_v.grid(alpha=0.3)
        self.fig.tight_layout()

    # ---------- лог и сохранение ----------
    def load_log(self):
        path = filedialog.askopenfilename(title="CSV-лог регистратора",
                                          filetypes=[("CSV", "*.csv"), ("Все файлы", "*.*")])
        if not path:
            return
        try:
            self.log = fs.load_log(path)
        except Exception as e:  # неверный формат файла
            messagebox.showerror("Ошибка", f"Не удалось прочитать лог:\n{e}")
            return
        self.recalc()

    def clear_log(self):
        self.log = None
        self.recalc()

    def save_png(self):
        path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG", "*.png")],
                                            initialfile="flight_sim.png")
        if path:
            self.fig.savefig(path, dpi=150)


if __name__ == "__main__":
    App().mainloop()
